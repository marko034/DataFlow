-Razmatramo skup vremenskih podataka iz Segedina u Madjarskoj izmedju 2006. i 2016.
-Potrebno je predvideti vidljivost odredjenog dana u odredjeno vreme
-Za ova predvidjanja korišćena je linearna regresija, stablo odlučivanja i metod najbližih suseda

-Data set se može naći na linku: https://www.kaggle.com/budincsevity/szeged-weather